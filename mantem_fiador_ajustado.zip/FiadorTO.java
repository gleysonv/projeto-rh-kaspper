
package br.gov.caixa.fes.dominio.transicao;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

@XmlRootElement
@Entity
@Table(name = "FESTB012_FIADOR")
@NamedNativeQuery(name = FiadorTO.QUERY_NAME, query = "{call FES.FESSP943_CONTRATO_CONSULTA ( ?, :1, :2, :3, :4, :5) }", resultClass = FiadorTO.class,
		hints = { @QueryHint(name = "org.hibernate.callable", value = "true") })
public class FiadorTO implements Serializable {

	private static final long serialVersionUID = -1376369463752127741L;

	public static final String QUERY_NAME="obterFiador";
	public static final String QUERY_BUSCAR_POR_CPF_FIADOR = "FiadorTO.buscarPorCpfFiador";
	public static final String QUERY_BUSCAR_POR_CPF_CONJUGE = "FiadorTO.buscarPorCpfConjuge";

    @EmbeddedId
    private FiadorTOPK id;

    @Column(name = "NU_SEQ_FIADOR")
    private int codigoFiador;

    @Column(name = "NU_CANDIDATO_FK10", insertable = false, updatable = false)
    private Long codigoFies = 0L;

    @Column(name = "CO_CPF_FIADOR", insertable = false, updatable = false)
    private String cpf = "";
	
	@Column(name = "NU_DEPENDENTE_CPF_FIADOR")//ok	
	private int dependenteCPF =0;

	@Column(name = "NO_FIADOR")//ok
	private String nome = "";
	
	@Column(name = "DT_NASCIMENTO")//ok
	private String dataNascimento;
	
	@Column(name = "CO_RIC_FIADOR")//ok
	private String ric= "";

	@Column(name = "DE_NACIONALIDADE")//ok
	private String nacionalidade;
	
	@Column(name = "CO_IDENTIDADE")//ok
	private String identidade;
	
	@Column(name = "SG_UF_EXPEDICAO_FK07")//ok
	private String ufExpedicao;
	
	@Column(name = "NU_ORGAO_EXPEDIDOR_FK79")//ok
	private Integer codigoOrgaoExpedidor;

	@Column(name = "DE_ORGAO_EXPEDIDOR")//ok
	private String orgaoExpedidor;

	@Column(name = "NU_ESTADO_CIVIL")//ok
	private Integer codigoEstadoCivil;

	@Column(name = "NU_REGIME_BENS", nullable = true)//ok
	private Integer codigoRegimeBens;
	
	@Column(name = "DT_EXPEDICAO")//ok
	private String dataExpedicaoIdentidade;
	
	@Column(name = "DE_ENDERECO")//ok
	private String endereco;

	@Column(name = "NO_BAIRRO")//ok
	private String bairro;
	
	@Column(name = "CO_CEP")//ok
	private String cep;

	@Column(name = "SG_UF_FK08")//ok
	private String uf;

	@Column(name = "NU_MUNICIPIO")//ok
	private Integer codigoCidade;

	@Column(name = "NO_MUNICIPIO")//ok
	private String nomeCidade;
	
	@Column(name = "CO_DDD")//ok
	private String dddTelefone;
	
	@Column(name = "CO_TEL")//ok
	private String numeroTelefone;

	@Column(name = "CO_DDD_CELULAR")//ok
	private String dddTelefoneCelular;

	@Column(name = "CO_TELEFONE_CELULAR")//ok
	private String numeroTelefoneCelular;

	@Column(name = "CO_DDD_COMERCIAL")//ok
	private String dddTelefoneComercio;

	@Column(name = "CO_TELEFONE_COMERCIAL")//ok
	private String numeroTelefoneComercio;
	
	@Column(name = "IC_EMANCIPADO")
	private String emancipado;
	
	@Column(name = "CO_MOTIVO_EMANCIPACAO")
	private String codigoMotivoEmancipado;

	@Column(name = "NO_CONJUGE")//ok
	private String nomeConjuge = "";
	
	@Column(name = "CO_CPF_CONJUGE")//ok
	private String cpfConjuge = "";
	
	
	@Column(name = "NU_DEPENDENTE_CPF_CONJUGE")//ok
	private int dependenteCPFConjuge=0;
	
	@Column(name = "DE_NACIONALIDADE_CONJUGE")//ok
	private String nacionalidadeConjuge = "";
	
	@Column(name = "DT_NASCIMENTO_CONJUGE")//ok
	private String dataNacimentoConjuge;

	@Column(name = "CO_IDENTIDADE_CONJUGE")//ok
	private String identidadeConjuge;

	
	@Column(name = "NU_ORGAO_EXPEDIDOR_CNJGE_FK79")//ok
	private Integer codigoOrgaoExpedidorConjuge;
	
	@Column(name = "SG_UF_EXPEDICAO_CONJUGE_FK07")//ok
	private String ufExpedicaoConjuge;
	
	@Column(name = "DT_EXPEDICAO_CONJUGE")//ok
	//@Temporal(TemporalType.DATE)
	private String dataExpedicaoIdentidadeConjuge;
		
	@Column(name = "CO_RIC_CONJUGE")//ok
	private String ricConjuge = "";
	
	@Column(name = "VR_RENDA_BRUTA_MENSAL")//ok
	private float rendaBrutaMensal = 0;

	@Column(name = "CO_OCUPACAO")//ok
	private String codigoProfissao;
	
	@Column(name = "DT_ATUALIZACAO")
	private Date dataAtualizacao = new Date();

	@Column(name = "DE_EMAIL_FIADOR")
	private String emailFiador;

	@Column(name = "DE_EMAIL_CONJUGE")
	private String emailConjuge;

    public FiadorTOPK getId() {
        return id;
    }

    public void setId(FiadorTOPK id) {
        this.id = id;
    }
	
	public Integer getCodigoEstadoCivil() {
		return codigoEstadoCivil;
	}

	public void setCodigoEstadoCivil(Integer codigoEstadoCivil) {
		this.codigoEstadoCivil = codigoEstadoCivil;
	}	
		
	public Integer getCodigoRegimeBens() {
		return codigoRegimeBens;
	}

	public void setCodigoRegimeBens(Integer codigoRegimeBens) {
		this.codigoRegimeBens = codigoRegimeBens;
	}	
		
	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	
	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}
	
	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}
	
	public Integer getCodigoCidade() {
		return codigoCidade;
	}

	public void setCodigoCidade(Integer codigoCidade) {
		this.codigoCidade = codigoCidade;
	}
	
	public String getNomeCidade() {
		return nomeCidade;
	}

	public void setNomeCidade(String nomeCidade) {
		this.nomeCidade = nomeCidade;
	}
	

	public String getDddTelefone() {
		return dddTelefone;
	}

	public void setDddTelefone(String dddTelefone) {
		this.dddTelefone = dddTelefone;
	}
	
	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	public String getDddTelefoneCelular() {
		return dddTelefoneCelular;
	}

	public void setDddTelefoneCelular(String dddTelefoneCelular) {
		this.dddTelefoneCelular = dddTelefoneCelular;
	}

	public String getNumeroTelefoneCelular() {
		return numeroTelefoneCelular;
	}

	public void setNumeroTelefoneCelular(String numeroTelefoneCelular) {
		this.numeroTelefoneCelular = numeroTelefoneCelular;
	}
	
	public String getDddTelefoneComercio() {
		return dddTelefoneComercio;
	}

	public void setDddTelefoneComercio(String dddTelefoneComercio) {
		this.dddTelefoneComercio = dddTelefoneComercio;
	}

	public String getNumeroTelefoneComercio() {
		return numeroTelefoneComercio;
	}

	public void setNumeroTelefoneComercio(String numeroTelefoneComercio) {
		this.numeroTelefoneComercio = numeroTelefoneComercio;
	}
	
	
	public String getRic() {
		return ric;
	}

	public void setRic(String ric) {
		this.ric = ric;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}	
	
	public String getUfExpedicao() {
		return ufExpedicao;
	}
	
	public void setUfExpedicao(String ufExpedicao) {
		this.ufExpedicao = ufExpedicao;
	}
	
	public String getIdentidade() {
		return identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public Integer getCodigoOrgaoExpedidor() {
		return codigoOrgaoExpedidor;
	}

	public void setCodigoOrgaoExpedidor(Integer codigoOrgaoExpedidor) {
		this.codigoOrgaoExpedidor = codigoOrgaoExpedidor;
	}

	public String getOrgaoExpedidor() {
		return orgaoExpedidor;
	}

	public void setOrgaoExpedidor(String orgaoExpedidor) {
		this.orgaoExpedidor = orgaoExpedidor;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
		
	public int getDependenteCPF() {
		return dependenteCPF;
	}

	public void setDependenteCPF(int dependenteCPF) {
		this.dependenteCPF = dependenteCPF;
	}	
	
	public Long getCodigoFies() {
		return codigoFies;
	}

	public void setCodigoFies(Long codigoFies) {
		this.codigoFies = codigoFies;
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getEmancipado() {
		return emancipado;
	}

	public void setEmancipado(String emancipado) {
		this.emancipado = emancipado;
	}
	
	public String getCodigoMotivoEmancipado() {
		return codigoMotivoEmancipado;
	}

	public void setCodigoMotivoEmancipado(String codigoMotivoEmancipado) {
		this.codigoMotivoEmancipado = codigoMotivoEmancipado;
	}
	
	
	public String getNomeConjuge() {
		return nomeConjuge;
	}

	public void setNomeConjuge(String nomeConjuge) {
		this.nomeConjuge = nomeConjuge;
	}

	public String getCpfConjuge() {
		return cpfConjuge;
	}

	public void setCpfConjuge(String cpfConjuge) {
		this.cpfConjuge = cpfConjuge;
	}

	public int getDependenteCPFConjuge() {
		return dependenteCPFConjuge;
	}

	public void setDependenteCPFConjuge(int dependenteCPFConjuge) {
		this.dependenteCPFConjuge = dependenteCPFConjuge;
	}

	
	public String getNacionalidadeConjuge() {
		return nacionalidadeConjuge;
	}

	public void setNacionalidadeConjuge(String nacionalidadeConjuge) {
		this.nacionalidadeConjuge = nacionalidadeConjuge;
	}

	public String getDataNacimentoConjuge() {
		return dataNacimentoConjuge;
	}

	public void setDataNacimentoConjuge(String dataNacimentoConjuge) {
		this.dataNacimentoConjuge = dataNacimentoConjuge;
	}

	public String getIdentidadeConjuge() {
		return identidadeConjuge;
	}

	public void setIdentidadeConjuge(String identidadeConjuge) {
		this.identidadeConjuge = identidadeConjuge;
	}

	public String getUfExpedicaoConjuge() {
		return ufExpedicaoConjuge;
	}

	public void setUfExpedicaoConjuge(String ufExpedicaoConjuge) {
		this.ufExpedicaoConjuge = ufExpedicaoConjuge;
	}

	public String getDataExpedicaoIdentidadeConjuge() {
		return dataExpedicaoIdentidadeConjuge;
	}

	public void setDataExpedicaoIdentidadeConjuge(
			String dataExpedicaoIdentidadeConjuge) {
		this.dataExpedicaoIdentidadeConjuge = dataExpedicaoIdentidadeConjuge;
	}

	public int getCodigoOrgaoExpedidorConjuge() {
		return codigoOrgaoExpedidorConjuge;
	}

	public void setCodigoOrgaoExpedidorConjuge(int codigoOrgaoExpedidorConjuge) {
		this.codigoOrgaoExpedidorConjuge = codigoOrgaoExpedidorConjuge;
	}

	public String getRicConjuge() {
		return ricConjuge;
	}

	public void setRicConjuge(String ricConjuge) {
		this.ricConjuge = ricConjuge;
	}

	public String getDataExpedicaoIdentidade() {
		return dataExpedicaoIdentidade;
	}

	public void setDataExpedicaoIdentidade(String dataExpedicaoIdentidade) {
		this.dataExpedicaoIdentidade = dataExpedicaoIdentidade;
	}
/*
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
*/

	public int getCodigoFiador() {
		return codigoFiador;
	}

	public void setCodigoFiador(int codigoFiador) {
		this.codigoFiador = codigoFiador;
	}

	public float getRendaBrutaMensal() {
		return rendaBrutaMensal;
	}

	public void setRendaBrutaMensal(float rendaBrutaMensal) {
		this.rendaBrutaMensal = rendaBrutaMensal;
	}

	public String getCodigoProfissao() {
		return codigoProfissao;
	}

	public void setCodigoProfissao(String codigoProfissao) {
		this.codigoProfissao = codigoProfissao;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public String getEmailConjuge() {
		return emailConjuge;
	}

	public void setEmailConjuge(String emailConjuge) {
		this.emailConjuge = emailConjuge;
	}

	public String getEmailFiador() {
		return emailFiador;
	}

	public void setEmailFiador(String emailFiador) {
		this.emailFiador = emailFiador;
	}
}