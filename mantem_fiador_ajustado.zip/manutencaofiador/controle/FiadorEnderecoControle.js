var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorEnderecoControle = Backbone.View
		.extend({
			selfModel : null,

			events : {
				'change #ufFiador' : 'changeUF',
				'change #cidadeFiador' : 'updateModel',
				'blur input' : 'updateModel',
			},

			initialize : function() {
				var that = this;
				console.log("initialize FiadorEndereco");
				$
						.get(
								BASE_FIADOR + '/visao/FiadorEndereco.html')
						.done(function(data) {
							that.template = _.template(data);
							that.render();
						});
			},

			render : function() {
				console.log('call -> FiadorEnderecoControle RENDER');
				// console.log(this.model);
				// return;
				try {
					this.selfModel = this.model.toJSON();
				} catch (e) {
					this.selfModel = this.model;
				}

				$(this.el).html(this.template(this.selfModel));

				var _this = this;
				
				console.log(_this.model.get("endereco"));
				var wCidade=_this.model.get("endereco").cidade.codigoCidade;
				var wUF1=_this.model.get("endereco").cidade.uf.sigla;
							console.log(wUF1);
				
				var modelUF = new UFColecao();
				
				// return;
				modelUF.buscar().done(
						function(collection) {
							console.log(wUF1);
							// var wSelecionado = $("#ufFiador").val();
							gMontaSelect("#ufFiador", "sigla", "sigla",
									collection, wUF1);
							window.setTimeout(function(){
								_this.atulizaCidade(wCidade);
							},1000);
							
						});

				return this;
			},

			changeUF : function(e) {
				console.log("changeUF");
				console.log(e);
				if (this.selfModel.endereco == null)
					this.selfModel.endereco = new Endereco.toJSON();
					
				if (this.selfModel.endereco.cidade == null){
					this.selfModel.endereco.cidade = new Cidade().toJSON();					
				}
				
				this.selfModel.endereco.cidade.uf = {
						sigla : $("#ufFiador").val()
				};
				this.atulizaCidade();
			},
			
			atulizaCidade : function(cidade) {
				console.log('call -> FiadorEnderecoControle -> atulizaCidade');

				if (cidade==undefined)
					cidade=-1;
				
				var _this = this;

				var modelCidade = new CidadeColecao();
				
				modelCidade
						.buscar(_this.selfModel.endereco.cidade.uf.sigla)
						.done(
								function(collection) {

									console
											.log("call -> FiadorEnderecoControle -> CidadeColecao");

									// var wSelecionado =
									// this2.endereco.cidade.codigoCidade;

									gMontaSelect("#cidadeFiador",
											"codigoCidade", "nome", collection,
											cidade);

									_this.updateModel();
								});
			},

			updateModel : function(el) {
				console.log("call -> FiadorEnderecoControle -> updateModel;")
				// funcao de chamada dos inputs
				console.log(this.model);
				// return;
				var wEd = this.model.get("endereco");

				wEd.endereco = $("#enderecoFiador2").val();
				wEd.bairro = $("#bairroFiador").val();
				wEd.cep = purificaAtributo($("#cepFiador").val());

				var wUf = {
					sigla : $("#ufFiador").val(),
					descricao : $("#ufFiador").val()
				};
				var wCidade = {
					codigoCidade : $("#cidadeFiador").val(),
					nome : $("#cidadeFiador option:selected").text(),
					uf : wUf
				};
				wEd.cidade = wCidade;

				delete wEd["uf"];
				// delete wEd.cidade["codigoIBGE"];
			}

		});