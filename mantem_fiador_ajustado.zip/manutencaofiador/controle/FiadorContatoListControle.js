var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorContatoListControle = Backbone.View.extend({
		
	events:
	{
		
	},

    initialize: function () {
    	var that = this;
    	console.log ("call -> FiadorContatoListControle");
    	
    	$.get(BASE_FIADOR + '/visao/FiadorContatoList.html').done(function(data){
    		that.template = _.template(data);
	    	that.render();	    		
    	});	   
    },

    render: function () {
    	$(this.el).html(this.template(this.model.toJSON()));
    	return this;
    },

});

