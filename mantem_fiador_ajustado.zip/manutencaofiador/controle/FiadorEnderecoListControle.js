var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorEnderecoListControle = Backbone.View.extend({
		
		events:
		{			
		},

	    initialize: function () {
	    	var that = this;

	    	$.get(BASE_FIADOR + '/visao/FiadorEnderecoList.html').done(function(data){
	    		that.template = _.template(data);
		    	that.render();	    		
	    	});	    	
	    },

	    render: function () {
	    	console.log (this.model);
	    	console.log ("call -> FiadorEnderecoListControle -> render -> fim");
	    	$(this.el).html(this.template(this.model.toJSON()));
	    	return this;
	    },
	});