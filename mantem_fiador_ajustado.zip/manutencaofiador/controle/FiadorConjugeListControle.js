window.FiadorConjugeListControle = Backbone.View.extend({
	modelExpedidor : null,
	modelUF : null,
	modalNacionalidade : null,

	events : {},

	initialize : function() {
		console.log("initialize FiadorConjugeListControle");
		// console.log(this.model);
		this.template = _.template(tpl.get('FiadorConjugeListControle'));
		this.render();
	},

	render : function() {
		console.log('FiadorConjugeListControle RENDER');
		console.log(this.model);
		console.log(this.template);
		$(this.el).html(this.template(this.model.toJSON()));
		console.log('fim render!');

		return this;
	},

});
