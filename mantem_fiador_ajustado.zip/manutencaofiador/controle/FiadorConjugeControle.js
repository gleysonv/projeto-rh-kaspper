var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorConjugeControle = Backbone.View.extend({
	modelUF : null,
	modelExpedidor : null,
	modalNacionalidade : null,

	events : {
		// "change" : "change",
		'blur input' : 'updateModel',
		'change select' : 'updateModel2',
		"changeDate .data" : "changeDate2"
	},

	initialize : function() {
		var that = this;
		console.log("initialize FiadorEndereco");
		$.get(BASE_FIADOR + '/visao/FiadorConjuge.html').done(function(data) {
			that.template = _.template(data);
			that.render();
		});
	},

	render : function() {
		console.log('FiadorConjugeControle RENDER');
		console.log(this.model);

		var _this2;

		try {
			_this2 = this.model.toJSON();

		} catch (e) {
			_this2 = this.model;
		}

		if (_this2.conjuge == null) {
			_this2.conjuge = new Conjuge().toJSON();
		}

		$(this.el).html(this.template(_this2));

		this.modelUF = new UFColecao();
		this.modelUF.buscar().done(function(collection) {
			var wSelecionado = _this2.conjuge.identidade.uf.sigla;
			gMontaSelect("#ufIdentidadeConjuge", "sigla", "sigla", collection, wSelecionado);
		});

		this.modelExpedidor = new OrgaoExpedidorColecao();
		this.modelExpedidor.buscar().done(function(collection) {
			var wSelecionado = _this2.conjuge.identidade.orgaoExpedidor.codigo;
			gMontaSelect("#orgaoExpedidorConjuge", "codigo", "nome", collection, wSelecionado);
		});

		gCarregarPaises("#nacionalidadeConjuge", _this2.nacionalidade.codigo);

		window.setTimeout(function() {
			loadMask();
		}, 800);

		// console.log('fim render!');

		return this;
	},

	updateModel2 : function(el) {
		console.log("call -> FiadorConjugeControle -> updateModel2");
		console.log(el);

		var $el = $(el.target);
		var wA = $el.attr('name');

		console.log(wA);

		if (wA == undefined) {
			console.log("call -> FiadorConjugeControle -> updateModel2 undefined");

			var wId = {
				identidade : $("#identidadeConjuge").val(),
				orgaoExpedidor : {
					codigo : $("#orgaoExpedidorConjuge").val(),
					nome : $("#orgaoExpedidorConjuge option:selected").text()
				},
				dataExpedicaoIdentidade : $("#dataExpedicaoIdentidadeConjuge").val(),

				uf : {
					sigla : $("#ufIdentidadeConjuge").val(),
					descricao : $("#ufIdentidadeConjuge").val()
				}
			};

			this.model.set("identidade", wId);
		}

		this.updateModel(el);
	},

	updateModel : function(el) {
		console.log("call -> updateModel");

		var wC = this.model.get("conjuge");

		wC.nome = $("#nomeConjuge").val();
		wC.dataNascimento = $("#dataNascimentoConjuge").val();

		var wCpf = new String($("#cpfConjuge").val());
		wC.cpf = purificaAtributo(wCpf);

		var wRic = new String($("#ricConjuge").val());
		wC.ric = purificaAtributo(wRic);
		
		var wId = wC.identidade;
		wId.identidade = $("#identidadeConjuge").val();
		wId.dataExpedicaoIdentidade = $("#dataExpedicaoIdentidadeConjuge").val();

		var wOrg = {
			codigo : $("#orgaoExpedidorConjuge").val(),
			nome : $("#orgaoExpedidorConjuge option:selected").text()
		}
		wId.orgaoExpedidor = wOrg;

		var wU = {
			sigla : $("#ufIdentidadeConjuge").val(),
			descricao : $("#ufIdentidadeConjuge").val()
		};
		wId.uf = wU;

		wC.nacionalidade = {
			codigo : $("#nacionalidadeConjuge").val(),
			nome : $("#nacionalidadeConjuge option:selected").text()
		};

		console.log(this.model);
	},

	changeDate2 : function changeDate2(e) {
		console.log("call -> ConsultaGenericaControle -> changeDate2");
		this.updateModel(e);
		/*
		 * console.log($('input', e.target).attr('name'));
		 * 
		 * this.model.set($('input', e.target).attr('name'), $('input',
		 * e.target).val()); console.log(this.model);
		 */
	},

});
