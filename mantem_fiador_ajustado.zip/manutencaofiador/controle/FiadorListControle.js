var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorListControle = Backbone.View.extend({

	events: {},

	initialize: function() {
		console.log("call -> FiadorListControle");
		var that = this;

		$.get(BASE_FIADOR + '/visao/FiadorList.html').done(function(data) {
			that.template = _.template(data);
			that.render();
		});
	},

	render: function() {
		console.log("call -> FiadorListControle -> render");
		console.log(this.model);
		$(this.el).html(this.template(this.model.toJSON()));
		return this;
	}
});