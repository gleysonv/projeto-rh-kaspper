var BASE_FIADOR = '../fes-web/servicos/contratofies/manutencaofiador';
window.FiadorContatoControle = Backbone.View.extend({

	events: {
		'blur input': 'updateModel',
	},

	initialize: function() {
		var that = this;
		console.log("call -> fiadorContatoControle -> initialize");
		$.get(BASE_FIADOR + '/visao/FiadorContato.html').done(function(data) {
			that.template = _.template(data);
			that.render();
		});
	},

	render: function() {
		var _this2;

		try {
			_this2 = this.model.toJSON();
		} catch (e) {
			_this2 = this.model;
		}

		$(this.el).html(this.template(_this2));
		return this;
	},

	updateModel: function(el) {
		console.log("call -> fiadorContatoControle -> updateModel");
		var wEd = this.model.get("contato");

		var wTelefone = {
			ddd: $("#dddFiador").val(),
			numero: purificaAtributo($("#telefoneFiador").val())
		};
		wEd.telefoneResidencial = wTelefone;

		var wTelefone2 = {
			ddd: $("#dddCelularFiador").val(),
			numero: purificaAtributo($("#celularFiador").val())
		};
		wEd.telefoneCelular = wTelefone2;

		var wTelefone3 = {
			ddd: $("#dddComercialFiador").val(),
			numero: purificaAtributo($("#telefoneComercialFiador").val())
		};
		wEd.telefoneComercial = wTelefone3;

	}

});