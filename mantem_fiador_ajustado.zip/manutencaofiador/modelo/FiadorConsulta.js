// Model auxiliar (linha do resultado)
window.FiadorConsulta = Backbone.Model.extend({
  defaults: {
    numeroContrato: '',
    cpfFiador: '',
    nomeFiador: '',
    dataNascimento: ''
  }
});

//# sourceURL=FiadorConsulta.js