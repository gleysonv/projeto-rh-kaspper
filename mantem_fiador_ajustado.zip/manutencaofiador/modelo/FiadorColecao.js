window.FiadorColecao = Backbone.Collection.extend({

	urlRoot: '../fes-web/emprest/administracao/cadastroFiadorContrato',

    model: Fiador,	
    
	buscar: function(){
		console.log ("call -> FiadorColecao -> buscar");
		//console.log (this.model);

		return this.fetch(        			
    			{
				type: "GET",
			    contentType: "application/json",
    			data: $.param({ "codigoFies": this.model.codigoFies})
    			
    			});
	}	
});