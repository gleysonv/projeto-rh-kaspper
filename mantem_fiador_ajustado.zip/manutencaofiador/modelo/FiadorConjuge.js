window.FiadorConjuge = Backbone.Model.extend({

	urlRoot: "../fes-web/emprest/administracao/fiadorConjuge",
	defaults : {
		codigo : 0,
		mensagem : "",
		cpf : "",
		nome : "",
		dependenteCPF : 0,
		dataNascimento : new Date(),
		ric : "",
		nacionalidade : new Nacionalidade(),
		identidade : new Identidade(),
	},

	validate: function(attributes, options) {
		console.log("call -> FiadorConjugeModel -> validate");

		if (attributes == undefined)
			return true;
		
		var errors = [];

		console.log(attributes);
				
		if (!attributes.nome) {
			errors.push({name: 'nome', message: 'Não foi informado o nome.'});
		}
		
		if (!attributes.cpf) {
			errors.push({name: 'nome', message: 'Não foi informado o cpf.'});
		}
		
		var wHoje = new Date();

		if (attributes.dataNascimento >= wHoje.getDate()) {
			errors.push({name: 'dataNascimento', message: 'A data de nacimento não pode ser maior que a data atual.'});
		}

		if (attributes.nacionalidade == null || !attributes.nacionalidade.nome){
			errors.push({name: 'nacionalidade', message: 'Não foi informado a nacionalidade'});
		}
		
		
		if (!attributes.identidade.identidade){
			errors.push({name: 'identidade.identidade', message: 'Não foi informado a identidade.'});
		}
		
		if (!attributes.identidade.dataExpedicaoIdentidade || attributes.identidade.dataExpedicaoIdentidade == "__/__/____"){
			errors.push({name: 'identidade.identidade', message: 'Não foi informado a data de expedição identidade.'});
		} else if(moment().isBefore(moment(attributes.identidade.dataExpedicaoIdentidade, 'DD/MM/YYYY'))) {
			errors.push({name: 'identidade.identidade', message: 'Data Expedição não pode ser superior à data atual.'});
		}

		if (identidade.orgaoExpedidor == null || !identidade.orgaoExpedidor.codigo){
			errors.push({name: 'identidade.identidade', message: 'Não foi informado o orgão expedidor.'});
		}
				
		if (attributes.identidade.uf == null || !attributes.identidade.uf.sigla){
			errors.push({name: 'identidade.identidade', message: 'Não foi informado a uf do orgão expedidor.'});
		}
				
		return errors.length > 0 ? errors : false;
	}
});
