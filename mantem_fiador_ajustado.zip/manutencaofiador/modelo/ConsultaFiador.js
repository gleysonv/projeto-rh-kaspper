
window.ConsultaFiador = Backbone.Model.extend({

    //  endpoint do FiadorRest
    urlRoot: '../fes-web/emprest/fiador/consultaFiadores',

    defaults: {
        cpf: '',
        codigoFiesConsulta: '',
        agenciaConsulta: ''
    },

    initialize: function () {
        this.set('cpf', '');
        this.set('codigoFiesConsulta', '');
        this.set('agenciaConsulta', '');
    },

    validate: function (attributes) {
        if (attributes === undefined)
        return true;

        var errors = [];

        var cpf = purificaAtributo(attributes.cpf || '');
        var codigoFies = purificaAtributo(attributes.codigoFiesConsulta || '');

        // Endpoint atual do sistema (/fiador/consultaFiadores) exige o código FIES.
        // Se enviar codigoFies="" o servidor estoura NumberFormatException.
        if (!codigoFies || codigoFies === '0.000') {
          errors.push({ message: 'Informe o Código FIES do estudante (ou use "Localizar Cód. Fies").' });
        } else if (cpf) {
          var msg = validarCPF(cpf);
          if (msg !== '') errors.push({ message: msg });
        }

        return errors.length > 0 ? errors : false;
    },

    buscar: function () {
        var cpf = purificaAtributo(this.attributes.cpf || '');
        var codigoFies = purificaAtributo(this.attributes.codigoFiesConsulta || '');

        var params = {};
        // o FiadorRest.consultaFiadores espera QueryParam("codigoFies")
        if (codigoFies) params.codigoFies = codigoFies;

        // (se você quiser permitir filtro por cpf na lista, só se o backend aceitar esse param)
        // if (cpf) params.cpf = cpf;

        return this.fetch({
          type: 'GET',
          data: $.param(params),
          cache: false
        });
    }

});
